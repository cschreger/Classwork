const uiReducer = (state = {}, action) => {
    return state;
};

export default uiReducer;